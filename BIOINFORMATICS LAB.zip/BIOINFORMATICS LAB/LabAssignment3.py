print("\nQuestion : 1\n")

List2= [[[8,7], [5,8]], [[5,5], [2,7]], [[1,1], [3,3], ['COMSATS',8,8]]]
print(List2[2][2][0][2])

print("\nQuestion : 2\n")

List1 = [2,5,7,8,3,4,7,6,9]
L = []
for i in range(len(List1)):
    if(i%2 == 0):
        L.append(List1[i])
print("Values on Even index : "+str(L))
m = int(len(List1)/2)
print("Mid-Value : "+str(List1[m]))
if(List1[m]%3 == 0):
    print("Mid Value is divisible by 3")
else:
    print("Mid Value is not divisible by 3")

print("\nQuestion : 3\n")

string="Pakistan is sacred land for Muslims. It got independence from British Rule on 14th August 1947. This country has been built with the belief of Two Nation Theory"
print("Extracted Text : " + string[78 : 94])
if string.find("British"):
    print("British is found in String.")
else:
    print("British is not found in String.")
new_string = ''.join((element for element in string if not element.isdigit()))
print("String without Numbers : ")
print(new_string + "\n")