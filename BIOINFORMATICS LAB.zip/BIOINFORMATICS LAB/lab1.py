list = []
for i in range(5):
    list.append(int(input("Enter "+str(i+1)+" number : ")))
print(list)

i = 0 ; sum = 0
while(i<=10):
    sum+=i ; i+=1
print(sum)