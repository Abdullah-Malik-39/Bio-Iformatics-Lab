from Bio import Entrez
from Bio import ExPASy
from Bio import SeqIO

#Entrez.email = "fa21-bcs-023@cuiatk.edu.pk"
#with Entrez.efetch(db = "nucleotide", rettype = "fasta", retmode = "text", id = "6273291") as handle:
#    seq = SeqIO.read(handle, "fasta")
#    print("%s  with  %i  features"%(seq.id , len(seq.features)))
    
with ExPASy.get_sprot_raw("q99j83") as handle:
    seq_1 = SeqIO.read(handle, "swiss")
    print(seq_1.id)
    print(seq_1.name)
    print(seq_1.description)
    print(seq_1.seq)
    print("Length %i" % len(seq_1))
    print(seq_1.annotations["keywords"])