from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
s = Seq("GATC")
sr = SeqRecord(s, id="1234")
sr.name = "Superman's DNA"
sr.description = "Kryptonite Sensitive"
sr.annotations["Cration Date "] = " 29/3/2022"
sr.annotations["Immunity(s) "] = " Fire , Bullets"
sr.annotations["Power(s) "] = " Strength , Flight"
sr.letter_annotations["Quality"] = [40,40,38,30]
print(sr)