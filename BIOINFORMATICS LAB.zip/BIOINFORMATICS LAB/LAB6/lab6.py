from Bio.Seq import Seq

def Validate_Seq(DNA):
    for character in DNA:
        if character not in ["A","C","G","T"]:
            return False
    return True

def Transcription(DNA):
    messenger_rna = Seq("")
    for index, character in enumerate(DNA):
        if DNA[index] == "T":
            messenger_rna+="U"
        else:
            messenger_rna+=character
    return messenger_rna

coding_dna = Seq("ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG")

if(Validate_Seq(coding_dna)):
    print(coding_dna)
    messenger_rna = Transcription(coding_dna)
    print(messenger_rna)
else:
    print("Wrong Sequence")    
