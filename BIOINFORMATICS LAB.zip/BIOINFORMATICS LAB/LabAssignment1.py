print("\nQuestion : 1\n")

Values = ["a" , "b" , "c" , "d" , "e"]
Keys = [1,2,3,4,5]
Dict = {}
for n in range(5):
    Dict[Keys[n]] = Values[n]
print(Dict)

print("\n\nQuestion : 2\n")

sentence = input("Enter Sentence :  ")
sentence = sentence.split()
for i in range(len(sentence)):
    if sentence[i][0] in "aeiou":
        sentence[i] += 'hay'
    else:
        sentence[i]=sentence[i][1:]+sentence[i][0]
        sentence[i]+='ay'
sentence = ' '.join(sentence)
print("Pig-Latin : " + sentence)