from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio import SeqIO

rec1 = SeqRecord(Seq("ACGTATAGCTACGATACGATCAGACTA"),
                 id = "Record1",description="Descrption of Protein 1")

rec2 = SeqRecord(Seq("GATCAGCATCGATCGACTACGATCGAC"),
                 id = "Record2",description="Descrption of Protein 2")

rec3 = SeqRecord(Seq("TACGATCGACTACGCACGCATAGCATC"),
                 id = "Record3",description="Descrption of Protein 3")

records = [rec1,rec2,rec3]
#SeqIO.write(records, "My_Records.faa", "fasta")
SeqIO.write(records, "GenBank.gb", "genbank")

#record = SeqIO.parse("GenBank.gbk" , "genbank")