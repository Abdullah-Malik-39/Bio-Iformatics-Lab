print("\nQuestion : 1\n")

h=float(input("Enter your height in meters: "))
w=float(input("Enter your Weight in Kg: "))
BMI=w/(h*h)
print("BMI Calculated is:  ",BMI)
if(BMI>0):
    if(BMI<=16):
        print("You are very underweight")
    elif(BMI<=18.5):
        print("You are underweight")
    elif(BMI<=25):
        print("Congrats! You are Healthy")
    elif(BMI<=30):
        print("You are overweight")
    else: 
        print("You are obese")
else:
    print("enter valid details")


print("\nQuestion : 2\n")

email = input("Enter E-mail : ")
name = email.split('@')[0]
host_name = email.split('@')[1]
f_name = name.split('.')[0]
l_name = name.split('.')[1]
print("First Name : "+f_name)
print("Last Name : "+l_name)
print("Hostname : "+host_name)

print("\nQuestion : 3\n")

def split(word):
    return [char for char in word]
string = input("Enter String : ")
l1 = split(string)
Dict = {}
for n in range(len(l1)):
    Dict[n+1] = l1[n]
print(Dict)