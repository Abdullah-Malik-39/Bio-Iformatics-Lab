from Bio.Seq import Seq
seq = Seq("AGTACACTGGT")
print("First Element : " + str(seq[0]))
print("Second Element : " + str(seq[1]))
print("Third Element : " + str(seq[2]))
print("Last Element : " + str(seq[10]))

