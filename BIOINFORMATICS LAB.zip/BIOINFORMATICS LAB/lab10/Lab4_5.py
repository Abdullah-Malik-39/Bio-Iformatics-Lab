from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
id_list = ["19304878", "18606172", "16403221", "16377612",
           "14871861", "14630660"]
print(Entrez.epost("pubmed", id=",".join(id_list)).read())


