from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.espell(term="biopythoon")
record = Entrez.read(handle)
print(record["Query"])
print(record["CorrectedQuery"])
