from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.egquery(term="biopython")
record = Entrez.read(handle)
for row in record["eGQueryResult"]:
    print(row["DbName"], row["Count"])

