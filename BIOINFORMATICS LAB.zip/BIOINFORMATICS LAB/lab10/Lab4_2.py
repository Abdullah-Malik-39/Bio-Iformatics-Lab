from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.einfo()
record = Entrez.read(handle)
handle.close()
print(record.keys())
print(record["DbList"])


