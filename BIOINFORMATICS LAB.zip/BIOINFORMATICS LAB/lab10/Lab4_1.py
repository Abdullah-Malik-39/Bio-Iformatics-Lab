from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.einfo()
result = handle.read()
handle.close()
print(result)

