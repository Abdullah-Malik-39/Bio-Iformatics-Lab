from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk"
handle = Entrez.esummary(db="nlmcatalog",
                         id="101660833")
record = Entrez.read(handle)
print(record)
info = record[0]["TitleMainList"][0]
print("Journal info\nid: {}\nTitle: {}"
      .format(record[0]["Id"], info["Title"]))
