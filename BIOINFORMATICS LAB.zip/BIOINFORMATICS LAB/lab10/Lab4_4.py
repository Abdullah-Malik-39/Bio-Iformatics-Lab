from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.esearch(db="pubmed", term="cancer")
record = Entrez.read(handle)
print(record["Count"])
print(record["IdList"])

