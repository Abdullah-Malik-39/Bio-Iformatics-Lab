from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.einfo(db="pubmed")
record = Entrez.read(handle)
#print(record["DbInfo"]["Description"])
print(record["DbInfo"]["Count"])
print(record["DbInfo"]["LastUpdate"])

