from Bio import Entrez
Entrez.email = "fa21-bcs-023@cuiatk.edu.pk" 
handle = Entrez.efetch(db="nucleotide",
                       id="EU490707", rettype="gb",
                       retmode="text")
print(handle.read())

